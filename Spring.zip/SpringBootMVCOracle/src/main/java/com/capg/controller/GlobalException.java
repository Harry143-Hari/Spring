package com.capg.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.capg.bean.Errorinfo;
import com.capg.exception.EmployeeExp;



@ControllerAdvice
public class GlobalException {

	
	@ExceptionHandler({EmployeeExp.class})
	@ResponseStatus(value=HttpStatus.NOT_FOUND,reason="Value Does not Exist")
	public Errorinfo handleException(Exception e, HttpServletRequest req) {
		
		String bodyOfResponse=e.getMessage();
		String uri = req.getRequestURI().toString();
		return new Errorinfo(uri,bodyOfResponse);
		
		
	}
	
	
	
}
