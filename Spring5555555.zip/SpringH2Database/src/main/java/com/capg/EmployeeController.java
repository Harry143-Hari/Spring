package com.capg;

import java.util.ArrayList;
import java.util.Iterator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class EmployeeController {

	@Autowired
	EmployeeRepo repo;
	
	
	@RequestMapping("/")
	public String form() {
		
		return "form";
	}
	
	@PostMapping("/display")
	public String display(EEEE emp, Model model) {
		
		model.addAttribute("emp",emp);
		
		
		repo.save(emp);
		
		
		return "display";
		
		
	}
	
	@RequestMapping(value="/getEmployee",method=RequestMethod.GET)
	@ResponseBody
	public String getEmployee(int eid) {
		
		// model.addAttribute("emp",emp);
		
		//int empid = Integer.parseInt(eid);
		
		
		EEEE emp=  repo.findById(eid).orElse(new EEEE());
		
	
		return emp.toString();
		
		
	}
	
	
	@GetMapping("/getAllEmployee")
	@ResponseBody
	public String getAllEmployee() {
		
		
		ArrayList<EEEE> list=new ArrayList<EEEE>();
		
		Iterable<EEEE> it = repo.findAll();
		
		
		Iterator<EEEE> itr = it.iterator();
		
		while (itr.hasNext()) {
			EEEE eeee = (EEEE) itr.next();
			
			list.add(eeee);
		
		}
		
		return list.toString();
	}
	
	
	
}
