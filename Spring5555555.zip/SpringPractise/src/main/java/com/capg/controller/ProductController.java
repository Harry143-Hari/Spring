package com.capg.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;


import com.capg.bean.Product;
import com.capg.exception.ProductException;
import com.capg.service.IProductService;


@RequestMapping("/product")
@RestController
public class ProductController {
	
	
	@Autowired
	IProductService service;
	
	
	
	@GetMapping(path="/get/{pid}")
	public Product fetchProductbyId(@PathVariable int pid) throws ProductException {
		
		
		if(service.fetchProduct(pid)==null) {
			
			throw new ProductException();
			
		}
		
		return service.fetchProduct(pid);
	}
	
	@GetMapping("/getall")
	public List<Product> fetchallProducts(){
		
	return service.fetchAll();	
		
	}
	
	
	@DeleteMapping(path="/delete/{pid}")
	public void deleteProductbyId(@PathVariable int pid) {
	
		service.deleteProduct(pid);
		
	}
	
	
	@PostMapping(path="/addnew",consumes="application/json")
	public Product addNewProduct(@RequestBody Product product) {
		
		return service.addProduct(product);
	}
	

	@PutMapping(path="/update",consumes="application/json")
	public Product UpdateProduct(@RequestBody Product product) {
		
		return service.updateProduct(product);
	}
	
	
	@ExceptionHandler({ ProductException.class })
	@ResponseStatus(value=HttpStatus.NOT_FOUND,reason="Value Does not Exist")
	public void handleException()
	{
		
	}
	
}
