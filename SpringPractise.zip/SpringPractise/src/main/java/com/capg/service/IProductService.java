package com.capg.service;

import java.util.List;

import com.capg.bean.Product;
import com.capg.exception.ProductException;

public interface IProductService {

	
	public Product addProduct(Product product);
	
	public Product updateProduct(Product product) throws ProductException;
	
	
	public Product fetchProduct(int pid);
	
	
	public void deleteProduct(int pid);
	
	public List<Product> fetchAll();
	
	
}
