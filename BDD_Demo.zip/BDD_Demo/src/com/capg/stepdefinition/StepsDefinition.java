package com.capg.stepdefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepsDefinition {

	WebDriver driver; 
	
	
	@Given("^Open any Browser and enter ICompass URL$")
	public void open_any_Browser_and_enter_ICompass_URL() throws Throwable {

		String path = "C:\\ChromeDriver\\chromedriver.exe";

		System.setProperty("webdriver.chrome.driver", path);

		driver = new ChromeDriver();

		String url = "https://icompassweb.fs.capgemini.com";
		driver.get(url);

	}

	@When("^user enters valid username \"([^\"]*)\" and valid password \"([^\"]*)\"$")
	public void user_enters_valid_username_and_valid_password(String username, String password) throws Throwable {

	WebElement userTextField =	driver.findElement(By.id("userName"));
		
	userTextField.sendKeys(username);
	
	WebElement passwordTextField =	driver.findElement(By.id("password"));
		
	passwordTextField.sendKeys(password);
		
		
	}

	@Then("^Display ICompass HomePage$")
	public void display_ICompass_HomePage() throws Throwable {

		
		WebElement loginb = driver.findElement(By.id("loginButton"));
		
		loginb.click();
		
		
	}
}
