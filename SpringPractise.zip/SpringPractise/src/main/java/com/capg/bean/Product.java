package com.capg.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;
import org.springframework.stereotype.Component;



@Component
@Table(name="product_example")
@Entity
public class Product {

	@NotNull
	@Id
	private int pid;
	@NotNull
	@Length(min=3, max=20)
	private String pname;
	@Max(value=90000)
	private double price;
	private double mno;
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public double getMno() {
		return mno;
	}
	public void setMno(double mno) {
		this.mno = mno;
	}
	
	
}
