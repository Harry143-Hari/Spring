insert into trainee values(101,'Java','Bangalore','Sri');
insert into trainee values(102,'Oracle','Chennai','Harry');
insert into trainee values(103,'Angular','Hyderabad','Hari');
insert into trainee values(104,'Spring 5','AndhraPradesh','Harish');