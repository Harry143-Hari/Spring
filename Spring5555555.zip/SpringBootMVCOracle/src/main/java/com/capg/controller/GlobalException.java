package com.capg.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.capg.bean.Errorinfo;
import com.capg.exception.EmployeeExp;

@ControllerAdvice
public class GlobalException {

	/* @ResponseStatus(value=HttpStatus.NOT_FOUND,reason="Value Does not Exist")
	/*
	 * public Errorinfo handleException(Exception e, HttpServletRequest req) {
	 * 
	 * String bodyOfResponse=e.getMessage(); String uri =
	 * req.getRequestURI().toString(); String error = e.set return new
	 * Errorinfo(uri,bodyOfResponse);
	 * 
	 * ResponseEntity<Errorinfo>
	 * }
	 */
	@ExceptionHandler({ EmployeeExp.class })
	@ResponseStatus(value=HttpStatus.NOT_FOUND,reason="Value Does not Exist")
	public Errorinfo handleException(EmployeeExp exp, HttpServletRequest req) {
		/*Errorinfo ei = new Errorinfo();
		HttpStatus status = HttpStatus.NOT_FOUND;
		String error = exp.getMessage();
		String message ="Exception Aaya Hai Dekh";
		String path =req.getRequestURI().toString();*/

		//return new ResponseEntity<>(ei, HttpStatus.NOT_FOUND);

		//return new Errorinfo(path,message,error,status);
	}

}
