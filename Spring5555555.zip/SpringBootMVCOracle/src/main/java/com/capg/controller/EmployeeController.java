package com.capg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.capg.bean.Employee;
import com.capg.exception.EmployeeExp;
import com.capg.service.IEmployeeService;

import net.bytebuddy.build.Plugin.Engine.Source.Empty;

@RestController
public class EmployeeController {

	@Autowired
	IEmployeeService service;
	
	@GetMapping(path="/employee/{eid}")
	public Employee getEmployeeById(@PathVariable int eid) throws EmployeeExp {
		
		
		Employee emp = service.getEmployeeById(eid);
		if(emp == null) 
		{
			
			
		throw new EmployeeExp();
		
		
		} 
		else
		return emp;
		
	}
	
	@GetMapping("/employees")
	public List<Employee> getAllEmployees() {
		
	
	return service.getAllEmployees();
		
	}
	
	
	@DeleteMapping(path="/employee/{eid}")
	public void deleteEmployeeById(@PathVariable int eid) {
		
		 service.deleteEmployeeById(eid);
		
		
	}
	
	
	
	@PostMapping(path="/employee", consumes="application/json")
	public Employee addEmployee(@RequestBody Employee emp) {
		
		
		return service.addEmployee(emp);
	}
	
	
	@PutMapping(path="/employee", consumes="application/json")
	public Employee updateEmployee(@RequestBody Employee emp) {
		
		return service.updateEmployee(emp);
	}
	

	@GetMapping(path="/employee/sal/{salary}")
	public List<Employee> getEmployeeBySalary(@PathVariable double salary) throws EmployeeExp {
		
		List<Employee> emp = service.getEmployeeSalary(salary);
		
		
		
		if(emp.size()== 0) 
		{
			
			
		throw new EmployeeExp();
		
		
		} 
		
		
		return emp;
	}
	
	
	@GetMapping(path="/employeerange")
	public List<Employee> getEmployeeBySalary() {
		
		List<Employee> emp = service.getEmployeeRange();
		
		return emp;
		
	}
	
	
	@GetMapping(path = "/employeesxml",produces="application/xml")
	public List<Employee> getEmployees() {
		
	
	return service.getAllEmployees();
		
	}
	
	
}
