package com.capg.exception;

public class ProductException extends Exception {

}
