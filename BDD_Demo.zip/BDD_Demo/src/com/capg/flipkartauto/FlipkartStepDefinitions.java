package com.capg.flipkartauto;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class FlipkartStepDefinitions {

	WebDriver driver;
	
	
	@Given("^Open any Browser and enter Flipkart URL$")
	public void open_any_Browser_and_enter_Flipkart_URL() throws Throwable {
	   

		String path = "C:\\ChromeDriver\\chromedriver.exe";

		System.setProperty("webdriver.chrome.driver", path);

		driver = new ChromeDriver();

		String url = "https://www.flipkart.com";
		driver.get(url);
		
	}
	
	
	@Given("^Click on Login&signup and Click on New to Flipkart$")
	public void click_on_Login_signup_and_Click_on_New_to_Flipkart() throws Throwable {
	   
	/*	WebElement userTextField =	driver.findElement(By.className("dHGf8H"));
		
		userTextField.sendKeys("/n");
	*/
	
		WebElement newbutton =	driver.findElement(By.className("V7ZJ4E"));
		
		newbutton.click();
		
		
	}
	
	
	
	
	@When("^User Enters valid MobileNo and Click on Continue$")
	public void user_Enters_valid_MobileNo_and_Click_on_Continue() throws Throwable {
	    
		WebElement newbutton =	driver.findElement(By.className("_2zrpKA"));
		
		newbutton.sendKeys("9865741236");
		
		
	}
	
	
	
	
	@Then("^Otp Sent by Flipkart and Recieved by Inputed MobileNo$")
	public void otp_Sent_by_Flipkart_and_Recieved_by_Inputed_MobileNo() throws Throwable {
	 
		
		WebElement submitbutton = driver.findElement(By.className("_7UHT_c"));
		
		
		submitbutton.click();
		
		
	}
	
	
	
	
	
}
